function aun() {


let suma = document.querySelector('#suma').value;
let period = document.querySelector('#period').value;
let rate = document.querySelector('#rate').value;
// let suma = +prompt("Введіть бажану суму кредиту: ");
// let period = +prompt("Введіть кількість місяців кредитування: ");
// let rate = +prompt("Введіть відсоткову ставку кредиту: ");


let percents = 0;
let monthlyPayment = 0; 
let mainDebt = 0;
// let remainSuma = 0;
// let ann = 0;
let table = document.querySelector(".table");
let str = '<table><caption>Ануїтентний кредит</caption><th>Борг на початок періоду</th><th>Основний борг</th><th>Відсотки</th><th>Щомісячний платіж</th></tr>';
let monthRate = rate/100/12;
monthlyPayment = (suma * (monthRate + (monthRate)/(Math.pow((1 + monthRate), period) - 1))).toFixed(2);


// let topPart = + (suma * monthRate).toFixed(2);
// let bottomPart = + (1 - (1 / Math.pow(monthRate + 1, period))).toFixed(2);
// aut = + (topPart / bottomPart).toFixed(2);


for(let i = 1; i <= period; i++) {
    
	percents = (suma * monthRate).toFixed(2);

	mainDebt = (monthlyPayment - percents).toFixed(2);

	suma = (suma - mainDebt).toFixed(2);
	

   str += `<tr><td>${suma}</td><td>${mainDebt}</td><td>${percents}</td><td>${monthlyPayment}</td></tr>`;
   console.log(i);
}

str += "</table>";
table.innerHTML = str;

// console.log("Ануїтентний щомісячний платіж" + ann);
}



function dif() {
// let suma = +prompt("Введіть бажану суму кредиту: ");
// let period = +prompt("Введіть кількість місяців кредитування: ");
// let rate = +prompt("Введіть відсоткову ставку кредиту: ");	

let suma = document.querySelector('#suma').value;
let period = document.querySelector('#period').value;
let rate = document.querySelector('#rate').value;

let dif = 0;
let persents = 0;
let remainSuma = suma;
let mainDebt = + (suma/period).toFixed(2);
let table = document.querySelector(".table");
let monthRate = rate / 12;

let str = "<table><caption>Диференційний кредит</caption><tr><th>Борг на початок періоду</th><th><th>Основний борг</th><th>Відсотки</th><th>Щомісячний платіж</th></tr>"

for (let i = 0; i < period; i++) {
    str += '<tr><td>' + remainSuma + '<td>' + '<td>' + mainDebt + '</td>';
    persents = + (remainSuma * monthRate).toFixed(2);
    str += '<td>' + persents + '</td>'; 
    remainSuma -= mainDebt;
    remainSuma = + (remainSuma).toFixed(2);
    dif = persents + mainDebt;
    str += '<td>'  + dif + '</td></tr>';
}

str += "</table>";
table.innerHTML = str;
}

aunButton.onclick = function(){
	aun()
}

difButton.onclick = function(){
	dif()
}